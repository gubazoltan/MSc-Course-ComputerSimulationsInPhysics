import numpy as np

def entry_transform(number,N):
    i = int(number/N)
    j = number-i*N
    return i,j

def create_neighs():
    even_neighbours = [[0,1],[1,0],[1,-1],[0,-1],[-1,-1],[-1,0]]
    odd_neighbours = [[0,1],[1,0],[1,1],[0,-1],[-1,0],[-1,1]]
    neighs = [even_neighbours,odd_neighbours]  
    return neighs

class Lattice:
    def __init__(self,N, particle_number, Beta):
        #create the empty lattice
        lattice_matrix = np.zeros(N*N).reshape((N,N))

        #fill the lattice with particle_number particles
        part_positions = np.random.choice(a = np.arange(N*N), size = particle_number, replace = False)

        #now transform the particle positions to fill in the lattice matrix
        for k in range(particle_number):
            i,j = entry_transform(part_positions[k],N)
            lattice_matrix[i,j] = 1 #place particle in the correct position
        
        self.lattice_matrix = lattice_matrix 
        self.size = N 
        self.particle_number = particle_number
        self.temp = Beta
        

    def int_energy(self,i,j):
        #calculate the energy of the current configuration by counting the number of neighbouring particles
        neighs = create_neighs()

        #size of the lattice
        N = self.size
        
        #calculate the energy of the electron configuration
        energy = 0
        #iterate through the neighbours
        for neigh in neighs[i%2]:
            neigh_i, neigh_j = (i+neigh[0])%N, (j+neigh[1])%N
            energy += self.lattice_matrix[neigh_i,neigh_j]
        return energy
        
    def new_configurations(self):
        neighs = create_neighs()
        
        Beta = self.temp
        N = self.size
        lattice = self.lattice_matrix
        
        #list all the possible configurations and the transition rates here
        new_configs = []
        rates = []
        #iterate through the lattice
        for i in range(N):
            for j in range(N):
                
                if lattice[i,j] == 1: #there is a particle in the lattice
                    E_old = self.int_energy(i,j) #calculate the energy of the old configuration
                    
                    for neigh in neighs[i%2]: #iterate through the neighbours
                        neigh_i, neigh_j = (i+neigh[0])%N, (j+neigh[1])%N #position of the neighbouring site in the lattice
                        #then if the neighbour is empty we can hop into it
                        if lattice[neigh_i,neigh_j] == 0:
                            #calculate the energy for this empty neighbouring site
                            E_new = self.int_energy(neigh_i,neigh_j)-1
                            rate = np.exp(-(E_old-E_new)*Beta)
                            new_configs.append([i,j,neigh_i,neigh_j,E_old,E_new])
                            rates.append(rate)
                            
        return new_configs, rates
    
    def update_lattice(self, i, j, new_i, new_j):
        lattice = self.lattice_matrix

        #destroy particle at site i,j
        lattice[i, j] = 0

        #and recreate the particle at site new_i,new_j
        lattice[new_i, new_j] = 1

        #update the lattice matrix
        self.lattice_matrix = lattice


    def find_transition(self, new_configs, rates):
        #from the possible new configurations randomly choose one and carry it out
        
        #total rate/"partition function"
        tot_rate = sum(rates)

        u = np.random.random()
        val = u*tot_rate

        l = -1
        while val > 0:
            l += 1
            val -= rates[l]
            
        #we need to carry out the l-th transition
        #new configuration will be this
        chosen_config = new_configs[l] 
        i, j, new_i, new_j = chosen_config[0], chosen_config[1], chosen_config[2], chosen_config[3]
        
        #update the lattice according to the new configuration
        self.update_lattice(i = i, j = j, new_i = new_i, new_j = new_j)

    def correlations(self):
        neighs = create_neighs()

        corr = 0

        N = self.size
        lattice = self.lattice_matrix
        
        for i in range(N):
            for j in range(N):
                for neigh in neighs[i%2]: #iterate through the neighbours
                    neigh_i, neigh_j = (i+neigh[0])%N, (j+neigh[1])%N #position of the neighbour 
                    corr += lattice[i,j]*lattice[neigh_i,neigh_j] #add the correlations 

        return corr/2 #avoid double counting
    
def simulate_TD_correlations(Lattice, it_num): 
    #find the time dependence of the correlations in the lattice
    corrs = []
    corrs.append(Lattice.correlations())
    
    #do it_num iterations
    for n in range(it_num):
        #create a new configuration with transition rates
        newconfigs, rates = Lattice.new_configurations()
        
        #update the lattice according to the transition rates
        Lattice.find_transition(new_configs = newconfigs, rates = rates)
        
        #add the new correlations to the corrs list
        corrs.append(Lattice.correlations())
        
    return np.array(corrs)

def simulate(Lattice, it_num): 
    #simulate the time evolution of the lattice but only calculate the final correlation
    
    #do it_num iterations
    for n in range(it_num):
        #create a new configuration with transition rates
        newconfigs, rates = Lattice.new_configurations()
        
        #update the lattice according to the transition rates
        Lattice.find_transition(new_configs = newconfigs, rates = rates)
      
    return Lattice.correlations()

def transition_point_finder(Betas, N, particle_number, it_num):
    final_corr = []
    
    #we want to use the same initial layout of particles for all the cases
    initial_lattice = Lattice(N = N, particle_number = particle_number, Beta = Betas[0])
    
    for Beta in Betas:
        #create a new lattice with Beta temperature
        current_lattice = Lattice(N = N, particle_number = particle_number, Beta = Beta)
        
        #set the lattice matrix of the new lattice to the lattice matrix of the initial lattice
        current_lattice.lattice_matrix = initial_lattice.lattice_matrix
        
        #get the final correlation of the current lattice for the given temperature
        cors = simulate(Lattice = current_lattice, it_num = it_num)
        
        final_corr.append(cors)
    return np.array(final_corr)/particle_number